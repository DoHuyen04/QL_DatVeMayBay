﻿using Microsoft.AspNetCore.Mvc;

namespace QLDatVeMayBay.Controllers
{
    public class ThongTinController : Controller
    {
        public IActionResult ChinhSach()
        {
            return View();
        }

        public IActionResult DieuKhoan()
        {
            return View();
        }

        public IActionResult DoiTac()
        {
            return View();
        }

        public IActionResult BaoChi()
        {
            return View();
        }
        public IActionResult VeChungToi()
        {
            return View();
        }

    }
}