﻿using Microsoft.AspNetCore.Mvc;

namespace QLDatVeMayBay.Controllers
{
    public class SanPhamController : Controller
    {
        public IActionResult VeMayBay()
        {
            return View();
        }

        public IActionResult KhachSan()
        {
            return View();
        }

        public IActionResult ChoThueXe()
        {
            return View();
        }

        public IActionResult HoatDong()
        {
            return View();
        }
    }
}