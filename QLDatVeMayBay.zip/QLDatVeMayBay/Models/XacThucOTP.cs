﻿using System.ComponentModel.DataAnnotations;

namespace QLDatVeMayBay.Models
{
    public class XacThucOTP
    {
        [Required]
        public string MaXacNhan { get; set; }
    }
}
